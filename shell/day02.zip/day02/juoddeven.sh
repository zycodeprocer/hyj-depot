#!/bin/bash
read -p "输入一个数字:" num
ramain=$[$num % 2]
#echo $ramain
if [ $ramain -eq 0 ];then
 echo "偶数"
elif [ $ramain -eq 1 ];then
 echo "奇数"
else
 echo "输入错误"
fi
