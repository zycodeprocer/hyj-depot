#!/bin/bash
#usage:检查文件是否存在,是否有执行权限
echo "检查文件是否存在，是否有x权限"
read -p "请输入要查看的文件:" file
if [ -e $file ];then
  echo "文件存在"
 if [ -x $file ];then
  echo "$file有执行权限"
 else
  echo "$file没有执行权限"
 fi
else
 echo "文件未知" 
fi
echo $0
