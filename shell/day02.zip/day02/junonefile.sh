#!/bin/bash
echo "删除路径下空文件!!!"
read -p "请输入文件路径:" dir
#oldcount=`ls $dir/* | wc -l`
#find $dir/* -type f -empty -delete
#newcount=`ls $dir/* | wc -l`
#rmcount=$[oldcount-newcount]
#echo "删除空文件个数:$rmcount"
if [ ! -e $dir ];then
 echo "$dir文件目录不存在"
 echo "感谢使用,zy写的$0脚本"
 exit
fi
count=0
for i in $dir/*
do
 if [ ! -s $i ];then
  rm $i
  ((count++)) 
 fi
done
echo "删除空文件个数:$count"
echo "程序名:$0"
