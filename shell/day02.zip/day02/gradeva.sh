#!/bin/bash
#usage:成绩评分
read -p "请输入你的成绩:" grade
if [ $grade -gt 100 ] || [ $grade -lt 0 ];then
 echo "输入错误"
else
 if [ $grade -le 100 ] && [ $grade -ge 95 ];then
  echo "优秀"
 elif [ $grade -lt 95 ] && [ $grade -ge 80 ];then
  echo "还不错"
 elif [ $grade -lt 80 ] && [ $grade -ge 60 ];then
  echo "加油"
 else
  echo "零分;gun"
 fi
fi
