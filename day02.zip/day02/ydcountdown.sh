#!/bin/bash
echo "元旦计时任务:"
for ((i=1;i>0;i++))
do
 year=`date "+%Y"`
 yd=`date -d "$year-01-01 00:00:00" +%s`
 now=`date +%s`
 let diff=yd-now
 let day=diff/86400
 let hour=diff%86400/3600
 let minute=diff%86400%3600/60
 let second=diff%86400%3600%60
echo "距离$year年的元旦还有$day天-$hour时:$minute分:$second秒."
 sleep 1
 clear
done
