#!/bin/bash
#usage:统计空行和注释
read -p "输入需要统计的文件路径:" dir
setnu=`cat $dir | grep -E '^$|^#' |wc -l`
echo "空行和#开头的有$setnu行"
echo "$0"
